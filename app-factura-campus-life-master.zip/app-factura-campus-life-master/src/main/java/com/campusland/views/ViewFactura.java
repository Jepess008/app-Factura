package com.campusland.views;

import java.time.LocalDateTime;

import com.campusland.exceptiones.clienteexceptions.ClienteNullException;
import com.campusland.exceptiones.clienteexceptions.ProductoNullException;
import com.campusland.respository.models.Cliente;
import com.campusland.respository.models.Factura;
import com.campusland.respository.models.ItemFactura;
import com.campusland.respository.models.Producto;

public class ViewFactura extends ViewMain{


    public static void startMenu() {

        int op = 0;

        do {

            op = mostrarMenu();
            switch (op) {
                case 1:
                    crearFactura();
                    break;
                case 2:
                    listarFactura();
                    break;
                default:
                    System.out.println("Opcion no valida");
                    break;
            }

        } while (op >= 1 && op < 6);

    }


    public static int mostrarMenu() {
        System.out.println("----Menu--Factura----");
        System.out.println("1. Crear factura.");
        System.out.println("2. Listar factura.");      
        System.out.println("3. Salir ");
        return leer.nextInt();
    }

    private static void crearFactura() {
    try {
        Cliente cliente = obtenerCliente();
        if (cliente != null) {
            Factura factura = new Factura(LocalDateTime.now(), cliente);
            Producto producto = obtenerProducto();
            if (producto != null) {
                ItemFactura itemFactura = crearItemFactura(producto);
                factura.agregarItem(itemFactura);
                serviceFactura.crear(factura);
                System.out.println("\nFactura creada con éxito\n");
            }
        }
    } catch (ClienteNullException | ProductoNullException e) {
        System.out.println("Error al crear la factura: " + e.getMessage());
    }
}

private static Cliente obtenerCliente() throws ClienteNullException {
    listarClientes();
    System.out.println("Ingrese el código del cliente");
    Cliente cliente = serviceCliente.porDocumento(leer.next());
    if (cliente == null)
        throw new ClienteNullException("El cliente no existe");
    return cliente;
}

private static Producto obtenerProducto() throws ProductoNullException {
    listarProductos();
    System.out.println("Ingrese el código del producto");
    Producto producto = serviceProducto.porCodigo(leer.nextInt());
    if (producto == null)
        throw new ProductoNullException("El producto no existe");
    return producto;
}

private static ItemFactura crearItemFactura(Producto producto) {
    ItemFactura itemFactura = new ItemFactura();
    itemFactura.setProducto(producto);
    System.out.println("Ingrese la cantidad");
    itemFactura.setCantidad(leer.nextInt());
    return itemFactura;
}

    public static void listarFactura() {
        System.out.println("Lista de Facturas");
        for (Factura factura : serviceFactura.listar()) {
            factura.display();
            System.out.println();
        }
    }
    
    private static void listarProductos() {
        System.out.println("Listado de productos\n");
        serviceProducto.listar().forEach(Producto::imprimir);
    }

    public static void listarClientes() {
        System.out.println("Lista de Clientes");
        serviceCliente.listar().forEach(cliente -> {
            cliente.imprimir();
            System.out.println();
        });
    }
}
