package com.campusland.exceptiones.clienteexceptions;

public class ProductoNullException extends ProductoException {

    public ProductoNullException(String mensaje) {
        super(mensaje);        
    }
    
}
