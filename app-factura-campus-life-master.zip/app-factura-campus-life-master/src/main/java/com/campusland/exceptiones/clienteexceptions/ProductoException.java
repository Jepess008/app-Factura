package com.campusland.exceptiones.clienteexceptions;

public class ProductoException extends Exception{

    public ProductoException(String mensaje) {
        super(mensaje);
    }
    
}
